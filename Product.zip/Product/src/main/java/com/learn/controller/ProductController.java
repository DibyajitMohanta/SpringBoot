package com.learn.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learn.entity.Product;
import com.learn.service.ProductService;

import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@RequestMapping("/product")
public class ProductController {
	private ProductService productService;
	//add
	@PostMapping
	public ResponseEntity<Product> createProduct(@RequestBody Product product){
		Product saveProduct=productService.createProduct(product);
		return new ResponseEntity<>(saveProduct,HttpStatus.CREATED);
	}
	//get single product
	@GetMapping("{id}")
	public ResponseEntity<Product> getProductId(@PathVariable("id") int productId)
	{
		Product product = productService.getProductById(productId);
		return new ResponseEntity<>(product,HttpStatus.OK);
	}
	//get all product
	@GetMapping
	public ResponseEntity<List<Product>> getAllProducts(){
		List<Product> products = productService.getAllProducts();
		return new ResponseEntity<>(products,HttpStatus.OK);
	}
	//update product
	@PutMapping("{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable("id") int productId,@RequestBody Product product)
	{
		product.setId(productId);
		Product updateProduct=productService.updateProduct(product);
		return new ResponseEntity<>(updateProduct,HttpStatus.OK);
	}
	@DeleteMapping("{id}")
	public ResponseEntity<String>deleteProduct(@PathVariable("id") int productId)
	{
		productService.deleteProduct(productId);
		return new ResponseEntity<>("Product successfull deleted !",HttpStatus.OK);
	}
	
}
