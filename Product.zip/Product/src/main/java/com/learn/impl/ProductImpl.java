package com.learn.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.learn.entity.Product;
import com.learn.repository.ProductRepository;
import com.learn.service.ProductService;

import lombok.AllArgsConstructor;
@Service
@AllArgsConstructor
public class ProductImpl implements ProductService {
	private ProductRepository productRepository;
//add
	@Override
	public Product createProduct(Product product) {
		
		return productRepository.save(product);
	}
//get single product
	@Override
	public Product getProductById(int productId) {
		Optional<Product> optionalProduct=productRepository.findById(productId);
		return optionalProduct.get() ;
	}
//get all product
	@Override
	public List<Product> getAllProducts() {
		
		return productRepository.findAll();
	}
//update
	@Override
	public Product updateProduct(Product product) {
		Product existingProduct = productRepository.findById(product.getId()).get();
		existingProduct.setName(product.getName());
		existingProduct.setPrice(product.getPrice());
		existingProduct.setQuantity(product.getQuantity());
		Product updatedProduct = productRepository.save(existingProduct);
		return updatedProduct;
	}
//delete
	@Override
	public void deleteProduct(int productId) {
		productRepository.deleteById(productId);
		
	}

}
